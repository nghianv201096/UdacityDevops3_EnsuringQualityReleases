Hi reviewer!
I have configured my custom log for selenium as follow:
# public logs to */var/logs/selenium* folder in virtual machine of environment
![Image](./selenium-logs-image/log-in-vm.png)

# connect vm to *log analytic workspace*
![Image](./selenium-logs-image/connect-vm.png)

# create custom log
![Image](./selenium-logs-image/custom-log-config.png)

# run the query
![Image](./selenium-logs-image/no-log-with-query.png)

However after many hours I can't see the logs when I query. I asked my coworkers who learned this course before and they said it sometime appear sometimes not and have to wait 1h to several days. 
I have setup many times for this project due to of limitation in Udacity session (8h). Currently I have a lot of other pending work to do because I have to finish this course by end of today occording to my organization policy then I spent most of last week for it. 

So, I'm very thankful if you can consider checking my work steps above instead of the result of log query.

Thank you in advance!